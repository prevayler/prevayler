package org.prevayler.demos.demo2;
	
public interface BankListener {
		
	public void accountCreated(Account account);
	public void accountDeleted(Account account);

}