package org.prevayler.demos.demo2;

public interface AccountListener {

	void accountChanged();
	
}
