// Prevayler(TM) - The Open-Source Prevalence Layer.
// Copyright (C) 2001 Klaus Wuestefeld.
// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License version 2.1 as published by the Free Software Foundation. This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details. You should have received a copy of the GNU Lesser General Public License along with this library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.

package org.prevayler.implementation;

import org.prevayler.Command;
import org.prevayler.PrevalentSystem;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPOutputStream;

/** Provides a simple API for writing commands and snapshots. This version supports
 * batching writes to disk by having a separate disk write thread. Writes are still
 * done synchronously i.e. writeAndExecuteCommand() does not return until your command
 * has been safely written to disk. Some options are available (see below)
 */
class BatchedCommandOutputStream implements Runnable {


    /** Maximum number of commands to commit in a single flush to disk*/
    private static int MAX_WRITE_BATCH_SIZE = Integer.parseInt(System.getProperty("PrevaylerMaxWriteBatchSize", "1000"));

    /** This number determines the size of the log files produces by the system. */
    public static final long LOG_FILE_SIZE = Long.parseLong(System.getProperty("PrevaylerLogFileSize", "5000000"));

    /** Should we GZIP the output for smaller log files and smaller disk writes. */
    public static final boolean GZIP_OUTPUT = Boolean.getBoolean(System.getProperty("PrevaylerGzipOutput", "true"));

    /** Should we execute on a different thread than the write thread. */
    public static final boolean ASYNC_EXECUTE = Boolean.getBoolean(System.getProperty("PrevaylerAsyncExecute", "true"));

    /** If true, resets object outputstream after writing each object to stream. When false resets only once per batch write (should support never...)
     * using false means smaller command logs and faster perf, but changes command behavior (be careful if you reuse command objects or objects
     * referenced by command objects )*/
    public static final boolean ALWAYS_RESET = Boolean.getBoolean(System.getProperty("PrevaylerAlwaysReset", "true"));

    private final NumberFileCreator fileCreator;

    private ObjectOutputStream logStream;

    private ByteCountStream fileStream;

    /** We remove from the writeCommandToDiskQueue and put onto
     * this queue so we have a stable queue to write to disk */
    private List internalWriteQueue = new LinkedList();

    /** App threads place commands on the queue. This class reads them off and writes them to disk */
    private List writeCommandToDiskQueue;

    private Map commandToExceptionMap;
    private Map commandToResultMap;
    private PrevalentSystem system;

    private ExecuteCommandThread executeCommandThread;

    public BatchedCommandOutputStream(NumberFileCreator fileCreator, PrevalentSystem system) {
        this.system = system;
        this.fileCreator = fileCreator;
        this.commandToExceptionMap = new HashMap();
        this.commandToResultMap = new HashMap();
        this.writeCommandToDiskQueue = new LinkedList();
        this.executeCommandThread = new ExecuteCommandThread(commandToExceptionMap, commandToResultMap, system);
        new Thread(executeCommandThread, "ExecuteCommandThread").start();
    }

    public Serializable writeAndExecuteCommand(Command command) throws Exception {
        //Wrap command in ClockRecoveryCommand
        command = new ClockRecoveryCommand(command, System.currentTimeMillis());

        //Lock queue and add command to it
        synchronized (writeCommandToDiskQueue) {
            writeCommandToDiskQueue.add(command);
            writeCommandToDiskQueue.notifyAll();
        }

        //Wait to be notified that this command was written to disk and executed
        synchronized (command) {
            while (true) {
                try {
                    command.wait();
                    break;
                } catch (InterruptedException e) {
                    e.printStackTrace(System.err);  //Should'nt happen
                }
            }
        }

        //Check if there are results for this command
        synchronized (commandToResultMap) {
            Object o = commandToResultMap.remove(command);
            if (o != null)
                return (Serializable) o;
        }

        //If no results there should be an exception
        synchronized (commandToExceptionMap) {
            Object o = commandToExceptionMap.remove(command);
            if (o instanceof Exception)
                throw (Exception) o;
        }

        throw new IllegalStateException("This should never happen! Why weren't there any results or exceptions?");
    }


    public void run() {
        while (true) {
            waitForSomethingToWrite();
            writeCommandQueueToDisk();
        }
    }

    /** Write the command queue to disk . Uses MAX_WRITE_BATCH_SIZE as the maximum number
     * of commands to do in one batch */
    private void writeCommandQueueToDisk() {
        // Lock queue while we read a batch of commands off it
        synchronized (writeCommandToDiskQueue) {
            //number of elements to write in this batch = min(MAX_WRITE_BATCH_SIZE,  writeCommandToDiskQueue.size())
            int size = writeCommandToDiskQueue.size();
            for (int i = 0; i < size && i < MAX_WRITE_BATCH_SIZE; i++) {
                internalWriteQueue.add(writeCommandToDiskQueue.remove(0));
            }
            //System.out.println("Writing: " + internalWriteQueue.size() + " Remaining: " + writeCommandToDiskQueue.size());
        }

        synchronized (system) { //prevent access to the system (e.g. snapshots) while writing to disk
            try {
                ObjectOutputStream oos = logStream();
                int numProcessed = 0;
                for (Iterator i = internalWriteQueue.iterator(); i.hasNext() && numProcessed < MAX_WRITE_BATCH_SIZE; numProcessed++) {
                    Command command = (Command) i.next();
                    oos.writeObject(command);
                    if(ALWAYS_RESET)
                        oos.reset();
                }
                if(!ALWAYS_RESET)
                    oos.reset();
                oos.flush();//Only one call per batch. Big speed increase ;-)
                if(ASYNC_EXECUTE)
                    executeCommandThread.executeCommands(internalWriteQueue);
                else
                    executeCommandThread.executeCommandSync(internalWriteQueue);
            } catch (Exception e) {
                addExceptionForCommands(e);
                notifyWaitingThreads();
                try {
                    closeLogStream();
                } catch (IOException e2) {//Nothing we can do
                }
                e.printStackTrace(System.err);
                //Print out so we don't lose original stack trace completely
            } finally {
                internalWriteQueue.clear();
            }
        }
    }

    /** Add the Exception that occured to the map for all the commands
     * that were supposed to have been written.
     * @param e the exception that occured that we are adding to the map
     */
    private void addExceptionForCommands(Exception e) {
        synchronized (commandToExceptionMap) {
            for (Iterator i = internalWriteQueue.iterator(); i.hasNext();) {
                commandToExceptionMap.put(i.next(), e);
            }
        }
    }

    /** Notify application threads waiting for their commands to be
     * written & executed that their results are ready */
    private void notifyWaitingThreads() {
        for (Iterator i = internalWriteQueue.iterator(); i.hasNext();) {
            Object o = i.next();
            synchronized (o) {
                o.notifyAll();
            }
            i.remove();
        }
    }

    /**Wait to be notified that the writeCommandToDiskQueue has had something added to it. */
    private void waitForSomethingToWrite() {
        synchronized (writeCommandToDiskQueue) {
            if (writeCommandToDiskQueue.size() == 0) {
                try {
                    writeCommandToDiskQueue.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace(System.err);
                }
            }
        }
    }

    ObjectOutputStream logStream() throws IOException {
        if (logStream == null) {
            fileStream = new ByteCountStream(fileCreator.newLog());
            if(GZIP_OUTPUT == true)
                logStream = new ObjectOutputStream(new GZIPOutputStream(fileStream));
            else
                logStream = new ObjectOutputStream(fileStream);
        }

        if (fileStream.bytesWritten() >= LOG_FILE_SIZE) {
            closeLogStream();
            return logStream();  //Recursive call.
        }

        return logStream;
    }

    void closeLogStream() throws IOException {
        if (logStream == null) return;

        logStream.close();
        logStream = null;
    }

    public synchronized void writeSnapshot(PrevalentSystem system) throws IOException {
        this.closeLogStream();    //After every snapshot, a new commandLog file must be started.

        File tempSnapshot = fileCreator.newTempSnapshot();

        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(tempSnapshot));
        stream.writeObject(system);
        stream.close();

        File snapshot = fileCreator.newSnapshot();
        if (!tempSnapshot.renameTo(snapshot)) throw new IOException("Unable to rename " + tempSnapshot + " to " + snapshot);
    }

}
