package org.prevayler.implementation;

import org.prevayler.Command;
import org.prevayler.PrevalentSystem;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.LinkedList;

/**  This class is responsible for executing commands already written to disk by
 * the BatchedCommandOutputStream. Commands are executed in the same order as
 * they were written to disk. Note that wen -DPrevaylerAsyncExecute=false is used
 * this class is called from the BatchedCommandOutputStream thread instead of it using
 * its own thread.
 *
 *
 * @author rweisber
 * @version $Revision: 1.3 $
 */
public class ExecuteCommandThread implements Runnable {

    private List executeQueue;

    private Map commandToExceptionMap;

    private Map commandToResultMap;

    private PrevalentSystem system;

    private SystemClock clock;


    ExecuteCommandThread(Map commandToExceptionMap, Map commandToResultMap, PrevalentSystem system) {
        this.executeQueue = new LinkedList();
        this.commandToExceptionMap = commandToExceptionMap;
        this.commandToResultMap = commandToResultMap;
        this.system = system;
        this.clock = (SystemClock) system.clock();
    }

    /** Pass these commands on to the executeCommandThread to execute. This will
     * return immediately
     * @param commandList list of commands to execute
     */
    public void executeCommands(List commandList) {
        synchronized (executeQueue) {
            for (Iterator i = commandList.iterator(); i.hasNext();) {
                executeQueue.add(i.next());
            }
            executeQueue.notifyAll();
        }
    }

    /** Bybasses the execute threads and executes these commands on the current thread.
     * Does not return immediately
     * @see #executeCommands
     * @param commandList list of commands to execute
     */
    public void executeCommandSync(List commandList) {
        synchronized (executeQueue) {
            for (Iterator i = commandList.iterator(); i.hasNext();) {
                executeQueue.add(i.next());
                processNextCommand();
            }
        }
    }

    public void run() {
        while (true) {
            processNextCommand();
        }
    }

    private void processNextCommand() {
        Command command = getNextCommandToExecute();
        try {
            //Pause clock wile recovering/executing
            clock.pause();
            try {
                commandToResultMap.put(command, command.execute(system));
            } catch (Exception e) {
                commandToExceptionMap.put(command, e);
            } finally {
                //Notify thread that results are available
                synchronized (command) {
                    command.notifyAll();
                }
            }
        } finally {
            clock.resume();
        }
    }

    private Command getNextCommandToExecute() {
        //Wait to be notified that the writeCommandToDiskQueue
        //has had something added to it.
        synchronized (executeQueue) {
            while (executeQueue.size() == 0) {
                try {
                    executeQueue.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace(System.err);
                }
            }
        }
        //Reacquire executeQueue monitor lost by doing executeQueue.wait()
        synchronized (executeQueue) {
            return (Command) executeQueue.remove(0);
        }

    }
}